import pygame
from pygame import *
pygame.init()
BLACK = (0, 0, 0)
RED = (255, 0, 0)
PURPLE = (255, 0, 127)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
large_font = pygame.font.SysFont('malgungothic', 70)
small_font = pygame.font.SysFont('malgungothic', 30)
screen_width = 600
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
class Brick:
    def make(self, column, row):
        global bricks
        self.column = column
        self.row = row
        for column_index in range(self.column):
            for row_index in range(self.row):
                brick = pygame.Rect(column_index * (60 + 10) + 35, row_index * (13 + 30) + 35, 60, 13)
                bricks.append(brick)
    def add(self):
        global bricks
        temp = []
        for brick in range(len(bricks)):
            temp.append(
                pygame.Rect(bricks[brick].x, bricks[brick].y + (13 + 30), bricks[brick].width, bricks[brick].height))
        for column_index in range(self.column):
            for row_index in range(1):
                brick = pygame.Rect(column_index * (60 + 10) + 35, row_index * (13 + 30) + 35, 60, 13)
                temp.append(brick)
        bricks = temp
bricks = []
brick_group = Brick()
def start():
    begin = True
    while begin:
        gamechange_image = small_font.render('press r to restart', True, BLACK)
        screen.blit(gamechange_image,
                    gamechange_image.get_rect(centerx=screen_width // 2, centery=screen_height // 2 + 50))
        title_image = large_font.render('벽돌깨기 PRO', True, WHITE)
        screen.blit(title_image, title_image.get_rect(centerx=screen_width // 2, centery=screen_height // 2 - 50))
        gamechange_image = small_font.render('press any key to start', True, WHITE)
        screen.blit(gamechange_image,
                    gamechange_image.get_rect(centerx=screen_width // 2, centery=screen_height // 2 + 50))
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_SPACE or event.key == K_UP:
                    begin = False
        pygame.display.update()
def runGame():
    global bricks
    score = 0
    missed = 0
    SUCCESS = 1
    FAILURE = 2
    game_over = 0

    COLUMN_COUNT = 8
    ROW_COUNT = 7

    ball = pygame.Rect(screen_width // 2 - 16 // 2, screen_height *5 // 6 - 16 // 2, 16, 16)
    ball_dx = 5
    ball_dy = -10

    paddle = pygame.Rect(screen_width // 2 - 80 // 2, screen_height - 16, 80, 16)
    paddle_dx = 0
    paddle_a = 0

    time = 0
    key_event = False

    bricks = []
    brick_group.make(COLUMN_COUNT, ROW_COUNT)
    while True:
        time += 1
        if (time % 200 == 0):
            brick_group.add()

        clock.tick(30)
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                break
            elif event.type == pygame.KEYDOWN:
                key_event = True
                if event.key == pygame.K_LEFT:
                    paddle_a = -2.0
                elif event.key == pygame.K_RIGHT:
                    paddle_a = 2.0
            else:
                key_event = False

        if not key_event:
            paddle_a = paddle_dx * -0.1

        if paddle.left <= 0 and paddle_dx < 0:
            paddle_dx = 0

        if paddle.right >= screen_width and paddle_dx > 0:
            paddle_dx = 0

        paddle_dx += paddle_a
        paddle.left += paddle_dx

        ball.left += ball_dx
        ball.top += ball_dy

        if ball.left <= 0:
            ball.left = 0
            ball_dx = -ball_dx
        elif ball.left >= screen_width - ball.width:
            ball.left = screen_width - ball.width
            ball_dx = -ball_dx
        if ball.top < 0:
            ball.top = 0
            ball_dy = -ball_dy
        elif ball.top >= screen_height:
            missed += 1
            ball.left = screen_width // 2 - ball.width // 2
            ball.top = screen_height*5 // 6 - ball.width // 2
            ball_dy = -ball_dy

        if missed >= 10:
            game_over = FAILURE
            break

        if paddle.left < 0:
            paddle.left = 0
        elif paddle.left > screen_width - paddle.width:
            paddle.left = screen_width - paddle.width

        for brick in bricks:
            if ball.colliderect(brick):
                bricks.remove(brick)
                ball_dy = -ball_dy
                score += 1
                break

        if ball.colliderect(paddle):
            ball_dy = -ball_dy
            if ball.centerx <= paddle.left or ball.centerx > paddle.right:
                ball_dx = ball_dx * -1
            ball_dx += paddle_dx * 3

        if ball_dx > 5:
            ball_dx = 5 + (ball_dx - 5) * 0.8

        if ball_dx < -5:
            ball_dx = -5 + (ball_dx + 5) * 0.8

        if len(bricks) == 0:
            print('success')


        for brick in bricks:
            pygame.draw.rect(screen, PURPLE, brick)

        if game_over == 0:
            pygame.draw.circle(screen, WHITE, (ball.centerx, ball.centery), ball.width // 2)

        pygame.draw.rect(screen, BLUE, paddle)

        score_image = small_font.render('Point {}'.format(score), True, YELLOW)
        screen.blit(score_image, (10, 10))

        missed_image = small_font.render('Missed {}'.format(missed), True, YELLOW)
        screen.blit(missed_image, missed_image.get_rect(right=screen_width - 10, top=10))

        pygame.display.update()
started = True
gamed = False
exit = False
oneloop = True
while True:
    if started:
        start()
        started = False
        gamed = True

    if gamed:
        if oneloop:
            runGame()
            oneloop = False
            gamechange_image = small_font.render('press r to restart', True, WHITE)
            screen.blit(gamechange_image,gamechange_image.get_rect(centerx=screen_width // 2, centery=screen_height // 2 + 50))
            pygame.display.update()

        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_r:
                    started = True
                    gamed = False
                    oneloop = True
                else:
                    gamed = False
                    exit = True
    if exit:
        break
pygame.quit()
