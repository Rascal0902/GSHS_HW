import pygame, random, time
from pygame.locals import *
# 죽고 r 누르면 재시작
# x 누르면 공격
# 점수가 늘때 파이프 생성
# 공격을 한 부작용으로 뒤에 예외적으로 파이프 추가
# 예외적으로 생긴 파이프를 통과해도 점수를 얻으며 점수가 늘었으므로 또 파이프 생성
# -> 공격을 한번이라도 하면 점점 파이프가 나오는 위치가 불규칙해짐

# Bird Class
class Bird(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)

        self.images = [pygame.image.load('assets/sprites/redbird-upflap.png').convert_alpha(),
                       pygame.image.load('assets/sprites/redbird-midflap.png').convert_alpha(),
                       pygame.image.load('assets/sprites/redbird-downflap.png').convert_alpha()
                       ]

        self.speed = SPEED

        self.current_image = 0
        self.image = pygame.image.load('assets/sprites/redbird-upflap.png').convert_alpha()
        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        self.rect[0] = WIDTH / 6
        self.rect[1] = HEIGHT / 2

    def update(self):
        self.current_image = (self.current_image + 1) % 3
        self.image = self.images[self.current_image]
        self.speed += GRAVITY

        self.rect[1] += self.speed

    def jump(self):
        self.speed = -SPEED

    def begin(self):
        self.current_image = (self.current_image + 1) % 3
        self.image = self.images[self.current_image]


class Ground(pygame.sprite.Sprite):

    def __init__(self, xpos):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load('assets/sprites/base.png').convert_alpha()
        self.image = pygame.transform.scale(self.image, (GROUND_WIDTH, GROUND_HEIGHT))

        self.mask = pygame.mask.from_surface(self.image)

        self.rect = self.image.get_rect()
        self.rect[0] = xpos
        self.rect[1] = HEIGHT - GROUND_HEIGHT

    def update(self):
        self.rect[0] -= GAME_SPEED


class Pipe(pygame.sprite.Sprite):

    def __init__(self, inverted, xpos, ysize):
        pygame.sprite.Sprite.__init__(self)
        self.scored = True
        self.image = pygame.image.load('assets/sprites/pipe-green.png').convert_alpha()
        self.image = pygame.transform.scale(self.image, (PIPE_WIDTH, PIPE_HEIGHT))

        self.rect = self.image.get_rect()
        self.rect[0] = xpos
        self.xpos = xpos
        self.ysize = ysize
        self.inverted = inverted
        if inverted:
            self.image = pygame.transform.flip(self.image, False, True)
            self.rect[1] = - (self.rect[3] - ysize)
            print(self.rect)
        else:
            self.rect[1] = HEIGHT - ysize

        self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        self.rect[0] -= GAME_SPEED
        self.score()
        # print("%%%%%%%%%%%")
        # print(MAXSCORE)
        # print(SCORE)

    def score(self):
        global SCORE
        global MAXSCORE
        global GAME_SPEED
        if self.rect[0]<WIDTH/6 and self.scored:
            SCORE = SCORE+1
            self.scored = False
            if(SCORE%2==0):
                pipes = get_random_pipes(WIDTH * 2)
                pipe_group.add(pipes[0])
                pipe_group.add(pipes[1])
        if MAXSCORE < SCORE:
            MAXSCORE = SCORE

        if SCORE > 20:
            GAME_SPEED = 25
        else:
            GAME_SPEED = 15

def is_off_screen(sprite):
    return sprite.rect[0] < -(sprite.rect[2])

def get_random_pipes(xpos):
    global yes
    size = random.randint(100, 300)
    pipe = Pipe(False, xpos, size)
    pipe_inverted = Pipe(True, xpos, HEIGHT - size - PIPE_GAP)
    return pipe, pipe_inverted



def start():
    global clock
    global bird
    global ground_group
    global begin
    global pipe_group
    global bird_group
    global SCORE
    SCORE = 0

    # Bird Sprite Group
    bird_group = pygame.sprite.Group()
    bird = Bird()
    bird_group.add(bird)

    # Ground Sprite Group
    ground_group = pygame.sprite.Group()
    for i in range(2):
        ground = Ground(GROUND_WIDTH * i)
        ground_group.add(ground)

    # Pipe Group
    pipe_group = pygame.sprite.Group()
    for i in range(2):
        pipes = get_random_pipes(WIDTH * i + 800)
        pipe_group.add(pipes[0])
        pipe_group.add(pipes[1])

    clock = pygame.time.Clock()

    # Begin Scene
    begin = True
    while begin:
        clock.tick(15)
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()

            if event.type == KEYDOWN:
                if event.key == K_SPACE or event.key == K_UP:
                    pygame.mixer.music.load(wing)
                    pygame.mixer.music.play()
                    begin = False

        screen.blit(BACKGROUND, (0, 0))
        screen.blit(BEGIN_IMAGE, (120, 150))
        scoreView(MAXSCORE, SCORE)

        # new ground add if one is off screen
        if is_off_screen(ground_group.sprites()[0]):
            ground_group.remove(ground_group.sprites()[0])

            new_ground = Ground(GROUND_WIDTH - 20)
            ground_group.add(new_ground)

        # Bird group draw
        bird.begin()
        bird_group.draw(screen)

        # ground group draw
        ground_group.update()
        ground_group.draw(screen)

        # Pipe group draw
        # pipe_group.update()
        # pipe_group.draw(screen)

        pygame.display.update()

oneloop2 = True
def game():
    global run, oneloop2
    global pipe_group
    # Main Loop
    print("Start Game")
    pygame.display.set_caption("Flappy Bird Game Start")

    run = True
    while run:
        clock.tick(15)
        for event in pygame.event.get():
            if event.type == QUIT:
                run = False

            if event.type == KEYDOWN:
                if event.key == K_SPACE or event.key == K_UP:
                    bird.jump()
                    pygame.mixer.music.load(wing)
                    pygame.mixer.music.play()

                if event.key == K_x:
                    if oneloop2 == True:
                     pipe_group.remove(pipe_group.sprites()[0])
                     pipe_group.remove(pipe_group.sprites()[0])
                     pipes = get_random_pipes(WIDTH * 2)
                     pipe_group.add(pipes[0])
                     pipe_group.add(pipes[1])
                     oneloop2 =False
                else:
                    oneloop2 = True
        # print("^^^^^^^^^^^^^^^")
        # print(len(pipe_group.sprites()))
        screen.blit(BACKGROUND, (0, 0))
        scoreView(MAXSCORE, SCORE)
        if is_off_screen(ground_group.sprites()[0]):
            ground_group.remove(ground_group.sprites()[0])
            new_ground = Ground(GROUND_WIDTH - 20)
            ground_group.add(new_ground)
        if is_off_screen(pipe_group.sprites()[0]):
            pipe_group.remove(pipe_group.sprites()[0])
            pipe_group.remove(pipe_group.sprites()[0])

        # Bird
        bird_group.update()
        bird_group.draw(screen)

        # ground group draw
        ground_group.update()
        ground_group.draw(screen)

        # Pipe group draw
        pipe_group.update()
        pipe_group.draw(screen)

        pygame.display.update()

        if (pygame.sprite.groupcollide(bird_group, ground_group, False, False, pygame.sprite.collide_mask) or
                pygame.sprite.groupcollide(bird_group, pipe_group, False, False, pygame.sprite.collide_mask)):
            pygame.mixer.music.load(hit)
            pygame.mixer.music.play()
            time.sleep(1)
            break
def scoreView(maxscore,score):
    maxscore = maxscore/2
    score = score/2

    MAXSCORE1x = 45
    MAXSCORE1y = 0
    MAXSCORE2x = 25
    MAXSCORE2y = 0
    MAXSCORE3x = 5
    MAXSCORE3y = 0

    SCORE1x = 45
    SCORE1y = 40
    SCORE2x = 25
    SCORE2y = 40
    SCORE3x = 5
    SCORE3y = 40

    NUMBER_WIDTH = 20
    NUMBER_HEIGHT = 40
    number0 = pygame.image.load('assets/sprites/0.png').convert_alpha()
    number0 = pygame.transform.scale(number0,(NUMBER_WIDTH,NUMBER_HEIGHT))
    number1 = pygame.image.load('assets/sprites/1.png').convert_alpha()
    number1 = pygame.transform.scale(number1, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number2 = pygame.image.load('assets/sprites/2.png').convert_alpha()
    number2 = pygame.transform.scale(number2, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number3 = pygame.image.load('assets/sprites/3.png').convert_alpha()
    number3 = pygame.transform.scale(number3, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number4 = pygame.image.load('assets/sprites/4.png').convert_alpha()
    number4 = pygame.transform.scale(number4, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number5 = pygame.image.load('assets/sprites/5.png').convert_alpha()
    number5 = pygame.transform.scale(number5, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number6 = pygame.image.load('assets/sprites/6.png').convert_alpha()
    number6 = pygame.transform.scale(number6, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number7 = pygame.image.load('assets/sprites/7.png').convert_alpha()
    number7 = pygame.transform.scale(number7, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number8 = pygame.image.load('assets/sprites/8.png').convert_alpha()
    number8 = pygame.transform.scale(number8, (NUMBER_WIDTH, NUMBER_HEIGHT))
    number9 = pygame.image.load('assets/sprites/9.png').convert_alpha()
    number9 = pygame.transform.scale(number9, (NUMBER_WIDTH, NUMBER_HEIGHT))
    maxscore1 = maxscore % 10
    maxscore2 = (maxscore//10) % 10
    maxscore3 = (maxscore//100) % 10
    score1 = score % 10
    score2 = (score//10) % 10
    score3 = (score//100) % 10
    if(maxscore1 == 0):
        screen.blit(number0,(MAXSCORE1x,MAXSCORE1y))
    if (maxscore1 == 1):
        screen.blit(number1,(MAXSCORE1x,MAXSCORE1y))
    if (maxscore1 == 2):
        screen.blit(number2,(MAXSCORE1x,MAXSCORE1y))
    if (maxscore1 == 3):
        screen.blit(number3,(MAXSCORE1x,MAXSCORE1y))
    if (maxscore1 == 4):
        screen.blit(number4,(MAXSCORE1x,MAXSCORE1y))
    if (maxscore1 == 5):
        screen.blit(number5, (MAXSCORE1x, MAXSCORE1y))
    if (maxscore1 == 6):
        screen.blit(number6, (MAXSCORE1x, MAXSCORE1y))
    if (maxscore1 == 7):
        screen.blit(number7, (MAXSCORE1x, MAXSCORE1y))
    if (maxscore1 == 8):
        screen.blit(number8, (MAXSCORE1x, MAXSCORE1y))
    if (maxscore1 == 9):
        screen.blit(number9, (MAXSCORE1x, MAXSCORE1y))
    if (maxscore2 == 0):
        screen.blit(number0, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 1):
        screen.blit(number1, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 2):
        screen.blit(number2, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 3):
        screen.blit(number3, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 4):
        screen.blit(number4, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 5):
        screen.blit(number5, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 6):
        screen.blit(number6, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 7):
        screen.blit(number7, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 8):
        screen.blit(number8, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore2 == 9):
        screen.blit(number9, (MAXSCORE2x, MAXSCORE2y))
    if (maxscore3 == 0):
        screen.blit(number0, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 1):
        screen.blit(number1, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 2):
        screen.blit(number2, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 3):
        screen.blit(number3, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 4):
        screen.blit(number4, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 5):
        screen.blit(number5, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 6):
        screen.blit(number6, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 7):
        screen.blit(number7, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 8):
        screen.blit(number8, (MAXSCORE3x, MAXSCORE3y))
    if (maxscore3 == 9):
        screen.blit(number9, (MAXSCORE3x, MAXSCORE3y))
    ##################################################################################################################
    if (score1 == 0):
        screen.blit(number0, (SCORE1x, SCORE1y))
    if (score1 == 1):
        screen.blit(number1, (SCORE1x, SCORE1y))
    if (score1 == 2):
        screen.blit(number2, (SCORE1x, SCORE1y))
    if (score1 == 3):
        screen.blit(number3, (SCORE1x, SCORE1y))
    if (score1 == 4):
        screen.blit(number4, (SCORE1x, SCORE1y))
    if (score1 == 5):
        screen.blit(number5, (SCORE1x, SCORE1y))
    if (score1 == 6):
        screen.blit(number6, (SCORE1x, SCORE1y))
    if (score1 == 7):
        screen.blit(number7, (SCORE1x, SCORE1y))
    if (score1 == 8):
        screen.blit(number8, (SCORE1x, SCORE1y))
    if (score1 == 9):
        screen.blit(number9, (SCORE1x, SCORE1y))
    if (score2 == 0):
        screen.blit(number0, (SCORE2x, SCORE2y))
    if (score2 == 1):
        screen.blit(number1, (SCORE2x, SCORE2y))
    if (score2 == 2):
        screen.blit(number2, (SCORE2x, SCORE2y))
    if (score2 == 3):
        screen.blit(number3, (SCORE2x, SCORE2y))
    if (score2 == 4):
        screen.blit(number4, (SCORE2x, SCORE2y))
    if (score2 == 5):
        screen.blit(number5, (SCORE2x, SCORE2y))
    if (score2 == 6):
        screen.blit(number6, (SCORE2x, SCORE2y))
    if (score2 == 7):
        screen.blit(number7, (SCORE2x, SCORE2y))
    if (score2 == 8):
        screen.blit(number8, (SCORE2x, SCORE2y))
    if (score2 == 9):
        screen.blit(number9, (SCORE2x, SCORE2y))
    if (score3 == 0):
        screen.blit(number0, (SCORE3x, SCORE3y))
    if (score3 == 1):
        screen.blit(number1, (SCORE3x, SCORE3y))
    if (score3 == 2):
        screen.blit(number2, (SCORE3x, SCORE3y))
    if (score3 == 3):
        screen.blit(number3, (SCORE3x, SCORE3y))
    if (score3 == 4):
        screen.blit(number4, (SCORE3x, SCORE3y))
    if (score3 == 5):
        screen.blit(number5, (SCORE3x, SCORE3y))
    if (score3 == 6):
        screen.blit(number6, (SCORE3x, SCORE3y))
    if (score3 == 7):
        screen.blit(number7, (SCORE3x, SCORE3y))
    if (score3 == 8):
        screen.blit(number8, (SCORE3x, SCORE3y))
    if (score3 == 9):
        screen.blit(number9, (SCORE3x, SCORE3y))

WIDTH = 400
HEIGHT = 600
SPEED = 20
GRAVITY = 2.5
GAME_SPEED = 15
SCORE = 0
MAXSCORE = 0

GROUND_WIDTH = 2 * WIDTH
GROUND_HEIGHT = 100

PIPE_WIDTH = 80
PIPE_HEIGHT = 500
PIPE_GAP = 150

# Sound
wing = 'assets/audio/wing.wav'
hit = 'assets/audio/hit.wav'
pygame.mixer.init()

# Initialize
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Bird")

# Image
BACKGROUND = pygame.image.load('assets/sprites/background-day.png')
BACKGROUND = pygame.transform.scale(BACKGROUND, (WIDTH, HEIGHT))
BEGIN_IMAGE = pygame.image.load('assets/sprites/message.png').convert_alpha()

started = True
gamed = False
exit = False
oneloop = True

while True:
    if started:
     start()
     started = False
     gamed = True

    if gamed:
     if oneloop:
      game()
      oneloop = False

     for event in pygame.event.get():
         if event.type == KEYDOWN:
          if event.key == K_r:
             started = True
             gamed = False
             oneloop = True
          else:
             gamed = False
             exit = True

    if exit:
     break

pygame.quit()


